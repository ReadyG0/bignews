# 用于 Vue

如果需要将 wangEditor 用于 Vue 中，可参见如下示例

- 下载源码 `git clone git@github.com:wangfupeng1988/wangEditor.git`
- 进入 vue 示例目录 `cd wangEditor/example/demo/in-vue/`，查看`src/components/Editor.vue`即可
- 也可以运行`npm install && npm run dev`查看在 vue 中的效果（`http://localhost:8080/`）
